from django.shortcuts import render
from app.forms import contactforms
# Create your views here.

def index(request):
    con = contactforms()
    return render(request,'index.html',{'form':con})