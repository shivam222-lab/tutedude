import requests
import os
import re
user = input("enter the img name : ")

user_agent = {
    "User_Agent":"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36"
}
url ="https://www.google.com/search?sca_esv=d76be41c69a404a4&rlz=1C1ONGR_enIN1114IN1114&q={user}&udm=2&fbs=AIIjpHxU7SXXniUZfeShr2fp4giZ1Y6MJ25_tmWITc7uy4KIeqDdErwP5rACeJAty2zADJjYuUnSkczEhozYdaq1wZrEheAY38UjnRKVLYFDREDmzz3c9iXgklNNbCtRRa3vQiDsiyngHMLCDiFcU14vRYFcn3hDvBtzesTsvCeqVb3Xc1wjI2MTiwr0UAtZV1SeaWYQtAHYGsCkaiqMHRd5y0JCw-KjIg&sa=X&ved=2ahUKEwjtiOH5obmOAxXkfPUHHek5HsYQtKgLKAF6BAgXEAE"

response = requests.get(url=url,headers=user_agent).content

pattern ="\[\"https://.*\.jpg\",[0-9]+,[0-9]+\ ]"
images = re.findall(pattern,response)

print("totl imges: {len(images)}")
no_of_imges=int(input("number of images to be downlod : "))
if images:
    if not os.path.exists(user):
       os.mkdir(user)
       os.chdir(user)
    else:
       os.chdir(user)
    for images in images[:no_of_imges]:
      images_url=eval(images)[0]
      response=requests.get(url=images_url).content
      images_name = images_url.split['/'][-1]

      with open(images_name , "wb")as file:
         file.write(response)