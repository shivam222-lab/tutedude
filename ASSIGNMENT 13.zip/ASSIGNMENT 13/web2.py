import urllib.request,urllib.parse,urllib.error
import requests

url = urllib.request.urlopen("http://127.0.0.1:8000/")

for line in url:
    print(line.decode().strip())





