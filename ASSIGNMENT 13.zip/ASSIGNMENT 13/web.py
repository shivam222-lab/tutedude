print(ord('e'))
print(ord('A'))
print(ord('2'))
print(ord( '*'))
