import requests
from bs4 import BeautifulSoup

class pricetracer:
    def __init__(self,url):
        self.url= url
        self.user_agent = {"User-Agent":"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36"}
        self.response = requests.get(url=self.url,headers=self.user_agent).text
        self.soup=BeautifulSoup(self.response,"lxml")
    def product_title(self):
        title = self.soup.find("span",{"id":"title"})
        if title is not None:
            return title.text
        else:
            return "tag not found"
    def product_price(self):
        price = self.soup.find("span",{"class":"aok-offscreen"})
        if price is not None:
            return price.text
        else:
            return "tag not found"
device = pricetracer(url="https://www.amazon.in/Samsung-Galaxy-Smartphone-Titanium-Storage/dp/B0CS5Z4GD3/ref=lp_4363159031_1_4?pf_rd_p=9e034799-55e2-4ab2-b0d0-eb42f95b2d05&pf_rd_r=ZJM6XDXHQBMSXMDQC9AP&sbo=RZvfv%2F%2FHxDF%2BO5021pAnSA%3D%3D&th=1")

print(device.product_title())
print(device.product_price())
