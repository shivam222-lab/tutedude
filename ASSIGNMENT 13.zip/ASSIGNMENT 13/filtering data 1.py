import requests
from bs4 import BeautifulSoup
def Extract(url):
 response= requests.get(url=url).content
 soup=BeautifulSoup(response,'lxml')
 tag=soup.find("td",{"id":"mp-right"})
 print(tag)
Extract(url="https://en.wikipedi.org/wiki/Main_Page")