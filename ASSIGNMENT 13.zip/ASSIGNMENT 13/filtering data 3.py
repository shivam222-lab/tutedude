import requests
from bs4 import BeautifulSoup

def extract(url):
    response = requests.get(url=url).content
    soup=BeautifulSoup(response,'lxml')
    tag=soup.find("td",{"id":"mp-right"})
    h=tag.find_all('h2')
    print(h)
extract(url="https://en.wikipedi.org/wiki/Main_Page")