from django.contrib import admin
from blog.models import post
# Register your models here.
admin.site.register(post)
