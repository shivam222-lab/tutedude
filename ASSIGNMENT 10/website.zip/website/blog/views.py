from django.shortcuts import render,get_object_or_404

from blog.models import post
# Create your views here.
def allpost(request):
    Post= post.objects.all()
    return render(request,'post.html',{'Post':Post})

def detail(request,blog_id):
    detail = get_object_or_404('post.pk = blog_id')
    return render(request,'details.html',{'post':detail})
